let texto = 'Declaração de variável com o let';
let a, b, c;
a = 1;
b = 2;
c = 3;

function PrimeiraFuncao() {
    let frase = 'texto inserido dentro da função';
    document.write(frase)
};
